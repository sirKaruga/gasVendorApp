<?php
header('Content-Type: application/json');

class MyDB extends SQLite3{
    function __construct()
    {
      $this->open('gasdb.db');
    }
  }

$conn = new MyDB();

$sqlQuery = "SELECT id,date,profit FROM day_profit ORDER BY id";

$result = $conn->query($sqlQuery);

$data = array();
foreach ($result as $row) {
	$data[] = $row;
}

#$conn->close();

echo json_encode($data);
?>