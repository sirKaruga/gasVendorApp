<html>

<head>
    <script language="javascript">
        function printdiv(printpage) {
            var headstr = "<html><head><title></title></head><body>";
            var footstr = "</body>";
            var newstr = document.all.item(printpage).innerHTML;
            var oldstr = document.body.innerHTML;
            document.body.innerHTML = headstr + newstr + footstr;
            window.print();
            document.body.innerHTML = oldstr;
            return false;
        }
    </script>
    <title>div print</title>
</head>

<body>
  <button> <a href="index.php">---Back to home</a></button>
    <input name="b_print" type="button" class="ipt" onClick="printdiv('div_print');" value=" Print ">
<?php
class MyDB extends SQLite3{
    function __construct()
    {
      $this->open('gasdb.db');
    }
  }
$db = new MyDB();
    function runQuery($query) {
        $db = new MyDB();
       $result = $db ->query($query);
        while ($row = $result->fetchArray(SQLITE3_ASSOC)){
            $resultset[] = $row;
        }       
        if(!empty($resultset))
            return $resultset;
    }

    ?>

    <div style="float: center; align-content: center; margin-left: 7em; width: 800px;" id="div_print">
       
        <table style="border: 1px solid grey; table-layout: fixed; margin-left: 7em; font-size: 12px; float: center; width: 800px;table-layout:fixed;word-wrap:break-word;border-collapse:collapse;" width="800px;" class="table table-striped table-bordered">
             
                 
            <caption><h2 style="border: 1px solid grey;">Ref.Mr.Maina's Gas Refill/Cylinder Financial Record as at<br> <?php $mydate=getdate(date("U"));
                    $b= "$mydate[month] $mydate[mday], $mydate[year]"; 
                    echo "$b";
                    ?></h2></caption>
            
            <tr>
                <th style="border: 3px solid black;" colspan="4" ><span style="float: center;"><b>DR.</span></b></th>
                <th style="border: 3px solid black;" colspan="4" ><span style="float: center; border-bottom: none;"><b>CR.</span></b></th>
            </tr>
            <tr style="border: 1px solid black;">
                <td><b>Date</b></td>
                <td><b>Serial</b></td>
                <td><b>Item</b></td>
                <td style='border-right: 3px solid black;'><b>Quantity(ksh.)</b></td>

                <td><b>Date</b></td>
                <td><b>Serial</b></td>
                <td><b>Item</b></td>
                <td><b>Quantity(ksh.)</b></td>
            </tr>
            
            
            
   <div style="display: none;">     
        <?php
          //   $dname=$_SESSION['myname'];
          // $x = explode(' ', $dname);
          // $result = "$x[0]";
        #$myquery = "SELECT * FROM comprehensive_sales";
        function Lineer(){
            $db = new MyDB();
        $results = $db->query('SELECT COUNT(*) FROM (SELECT `id`,* FROM `comprehensive_sales` ORDER BY `id` ASC);');
        while ($row = $results->fetchArray()) {
           $limit= $row["COUNT(*)"];
        } 

        // for purchse and expenses
        $results2 = $db->query('SELECT COUNT(*) FROM (SELECT `id`,* FROM `container_purchase` ORDER BY `id` ASC);');
        while ($row2 = $results2->fetchArray()) {
           $limi2= $row2["COUNT(*)"];
        } 

        if ($limit>$limi2) {
            $lesser=$limi2;
            $remainder= $limit - $limi2;
            $que0= "SELECT * FROM container_purchase ORDER BY `id` ASC";
           $que= "SELECT * FROM comprehensive_sales ORDER BY `id` ASC";
           
           for ($i=0; $i < $lesser; $i++) { 
               echo "
               
                <tr>
                    <td>".runQuery($que)[$i]['date']."</td>
                    <td>".runQuery($que)[$i]['receipt']."</td>
                    <td>".runQuery($que)[$i]['product']."</td>
                    <td style='border-right: 3px solid black;'><b>".runQuery($que)[$i]['t_sales']."</b></td>
                    
                
                    <td>".runQuery($que0)[$i]['date']."</td>
                    <td>".runQuery($que0)[$i]['receipt']."</td>
                    <td>".runQuery($que0)[$i]['product']."</td>
                    <td><b>".runQuery($que0)[$i]['t_bp']."</b></td>
                <tr>
                 ";
           }
           for ($i=$lesser; $i < $limit; $i++) { 
               echo "
               <tr>
                    <td>".runQuery($que)[$i]['date']."</td>
                    <td>".runQuery($que)[$i]['receipt']."</td>
                    <td>".runQuery($que)[$i]['product']."</td>
                    <td style='border-right: 3px solid black;'><b>".runQuery($que)[$i]['t_sales']."</b></td>
                    

                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>

                </tr>

                    ";
           }
            
        }else{
            $lesser=$limi;
            $remainder= $limit2 - $limi;
            $que0= "SELECT * FROM container_purchase ORDER BY `id` ASC";
           $que= "SELECT * FROM comprehensive_sales ORDER BY `id` ASC";
           
           for ($i=0; $i < $lesser; $i++) { 
               echo "<tr>
                    <td>".runQuery($que)[$i]['date']."</td>
                    <td>".runQuery($que)[$i]['receipt']."</td>
                    <td>".runQuery($que)[$i]['product']."</td>
                    <td>".runQuery($que)[$i]['t_sales']."</td>

                    <td>".runQuery($que0)[$i]['date']."</td>
                    <td>".runQuery($que0)[$i]['receipt']."</td>
                    <td>".runQuery($que0)[$i]['product']."</td>
                    <td>".runQuery($que0)[$i]['t_bp']."</td>
                    </tr>";
           }
           for ($i=$lesser; $i < $limit; $i++) { 
               echo "<tr>
                    <td></td>
                    
                    <td>".runQuery($que0)[$i]['date']."</td>
                    <td>".runQuery($que0)[$i]['receipt']."</td>
                    <td>".runQuery($que0)[$i]['product']."</td>
                    <td>".runQuery($que0)[$i]['t_bp']."</td>
                    </tr>";
           }

        }
    }
    ?>
</div>
<?php
   echo Lineer();
?>

         </table>

    </div>
    
</body>

</html>