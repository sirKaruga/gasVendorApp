<?php
 class MyDB extends SQLite3{
    function __construct()
    {
      $this->open('gasdb.db');
    }
  }
$db = new MyDB();
$mid= $_GET['id'];
// get values of record to delete

 $sql2= "SELECT * FROM gas_expense WHERE id='$mid'";
  $result = $db ->query($sql2);
 while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
    $hdate= $row['date'];
    $amount = $row['amount'];
  }

  $sql3= "SELECT * FROM day_profit WHERE date='$hdate'";
  $result2 = $db ->query($sql3);
 while ($row = $result2->fetchArray(SQLITE3_ASSOC)) {
    $p_profit= $row['profit'];
  }
  $new_sprofit = $p_profit + $amount;
 $profit_update="UPDATE day_profit
SET 
    profit='$new_sprofit'

WHERE
    date='$hdate'";
$db->query($profit_update);

$deleteR_aproducts="DELETE FROM gas_expense WHERE id='$mid'";
  $db->query($deleteR_aproducts);
// echo "<script>location:deleteproduct.php;</script>";
header('location:index.php');
?>