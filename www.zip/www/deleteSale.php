<?php
 class MyDB extends SQLite3{
    function __construct()
    {
      $this->open('gasdb.db');
    }
  }
$db = new MyDB();
$mid= $_GET['id'];
// get values of record to delete

 $sql2= "SELECT * FROM comprehensive_sales WHERE id='$mid'";
  $result = $db ->query($sql2);
 while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
    $name_id =$row['product'];
    $receipt=$row['receipt'];
    $hdate= $row['date'];
    $hprofit= $row['profit'];
    $a_3kg =$row['ml_100'];
    $a_6kg=$row['ml_150'];
    $a_13kg= $row['ml_200'];
    $a_15kg= $row['ml_250'];
  }
 
  
    $q="SELECT * FROM day_profit WHERE date='$hdate'";
    $i_profit_result = $db ->query($q);
 while ($row = $i_profit_result->fetchArray(SQLITE3_ASSOC)) {
    $i_profit =$row['profit'];
  }
  $new_profit= $i_profit - $hprofit;

  $profit_update="UPDATE day_profit
SET 
    profit='$new_profit'

WHERE
    date='$hdate'";
$db->query($profit_update);

$calibrations = "SELECT * FROM prod_calibrations WHERE product='$name_id'";
 $r_calibrations = $db ->query($calibrations);
 while ($row = $r_calibrations->fetchArray(SQLITE3_ASSOC)) {
    $_3kg =$row['ml_100'];
    $_6kg=$row['ml_150'];
    $_13kg= $row['ml_200'];
    $_15kg= $row['ml_250'];
  }
$new_3kg= $_3kg + $a_3kg;
$new_6kg=$_6kg + $a_6kg;
$new_13kg=$_13kg + $a_13kg;
$new_15kg=$_15kg + $a_15kg;

$calibration_update="UPDATE prod_calibrations
SET 
    ml_100='$new_3kg',
    ml_150='$new_6kg',
    ml_200='$new_13kg',
    ml_250='$new_15kg'
WHERE
    product='$name_id'";
$db->query($calibration_update);

 $x = explode('.', $receipt);
  $myresult = "$x[0]";
if ($myresult=='R') {

  $containers = "SELECT * FROM empty_containers WHERE product='$name_id'";
 $c_calibrations = $db ->query($containers);
 while ($row = $c_calibrations->fetchArray(SQLITE3_ASSOC)) {
    $s_3kg =$row['_3kg'];
    $s_6kg=$row['_6kg'];
    $s_13kg= $row['_13kg'];
    $s_15kg= $row['_15kg'];
  }
$news_3kg= $s_3kg - $a_3kg;
$news_6kg=$s_6kg - $a_6kg;
$news_13kg=$s_13kg - $a_13kg;
$news_15kg=$s_15kg - $a_15kg;

$container_update="UPDATE empty_containers
SET 
    _3kg='$news_3kg',
    _6kg='$news_6kg',
    _13kg='$news_13kg',
    _15kg='$news_15kg'
WHERE
    product='$name_id'";
$db->query($container_update);

}
$deleteR_aproducts="DELETE FROM comprehensive_sales WHERE id='$mid'";
  $db->query($deleteR_aproducts);
// echo "<script>location:deleteproduct.php;</script>";
header('location:index.php');
?>