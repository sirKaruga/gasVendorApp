<?php
session_start();
 // if(isset($_POST["Submit"])){
class MyDB extends SQLite3{
    function __construct()
    {
      $this->open('gasdb.db');
    }
  }

  $db = new MyDB();
  $mid=$_SESSION['id'];

  $bp_3kg =preg_replace('~\D~', '', $_POST['bp_3kg']);
  $sp_3kg =preg_replace('~\D~', '', $_POST['sp_3kg']);
  $bp_6kg =preg_replace('~\D~', '', $_POST['bp_6kg']);
  $sp_6kg =preg_replace('~\D~', '', $_POST['sp_6kg']);
  $bp_13kg =preg_replace('~\D~', '', $_POST['bp_13kg']);
  $sp_13kg =preg_replace('~\D~', '', $_POST['sp_13kg']);
  $bp_15kg =preg_replace('~\D~', '', $_POST['bp_15kg']);
  $sp_15kg =preg_replace('~\D~', '', $_POST['sp_15kg']);

  $r_bp_3kg =preg_replace('~\D~', '', $_POST['r_bp_3kg']);
  $r_sp_3kg =preg_replace('~\D~', '', $_POST['r_sp_3kg']);
  $r_bp_6kg =preg_replace('~\D~', '', $_POST['r_bp_6kg']);
  $r_sp_6kg =preg_replace('~\D~', '', $_POST['r_sp_6kg']);
  $r_bp_13kg =preg_replace('~\D~', '', $_POST['r_bp_13kg']);
  $r_sp_13kg =preg_replace('~\D~', '', $_POST['r_sp_13kg']);
  $r_bp_15kg =preg_replace('~\D~', '', $_POST['r_bp_15kg']);
  $r_sp_15kg =preg_replace('~\D~', '', $_POST['r_sp_15kg']);
  

$new_pdate= "UPDATE aproducts
SET 
    bp_100='$bp_3kg',
    sp_100='$sp_3kg',
    bp_150='$bp_6kg',
    sp_150='$sp_6kg',
    bp_200='$bp_13kg',
    sp_200='$sp_13kg',
    bp_250='$bp_15kg',
    sp_250='$sp_15kg',
    r_bp_3kg='$r_bp_3kg',
    r_sp_3kg='$r_sp_3kg',
    r_bp_6kg='$r_bp_6kg',
    r_sp_6kg='$r_sp_6kg',
    r_bp_13kg='$r_bp_13kg',
    r_sp_13kg='$r_sp_13kg',
    r_bp_15kg='$r_bp_15kg',
    r_sp_15kg='$r_sp_15kg'
WHERE
    id='$mid'";
    if ($db->query($new_pdate)) {
       header('location:updateprices.php');
    }else{echo "error_log";}
//}

  ?>