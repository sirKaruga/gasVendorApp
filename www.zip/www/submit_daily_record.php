<!DOCTYPE html>
<html>
<head>
</head>
<body style="display: none;">

<?php
class MyDB extends SQLite3{
    function __construct(){
      $this->open('gasdb.db');
    }}
function randStrGen($len){
	$result = "";
	$chars = "ABDEFGHIJKLMNOPQSTUVWXYZ0123456789abcdefghijklmnpqrstuvwxyz";
	$charArray = str_split($chars);
	for ($i=0; $i < $len; $i++) { 
		$randItm = array_rand($charArray);
		$result .="".$charArray[$randItm];
	}
	return "C.".$result;
}
  $db = new MyDB();

  $f1_date = $_POST['f1_date']; 
  $f1_name = $_POST['f1_name'];
  $f1_100 = preg_replace('~\D~', '', $_POST['f1_3kg']);
  $f1_150 = preg_replace('~\D~', '', $_POST['f1_6kg']);
  $f1_200 = preg_replace('~\D~', '', $_POST['f1_13kg']);
  $f1_250 = preg_replace('~\D~', '', $_POST['f1_15kg']);
  

  $f2_date = $_POST['f2_date'];
  $f2_name = $_POST['f2_name'];
  $f2_100 = preg_replace('~\D~', '', $_POST['f2_3kg']);
  $f2_150 = preg_replace('~\D~', '', $_POST['f2_6kg']);
  $f2_200 = preg_replace('~\D~', '', $_POST['f2_13kg']);
  $f2_250 = preg_replace('~\D~', '', $_POST['f2_15kg']);
  

  $f3_date = $_POST['f3_date'];
  $f3_name = $_POST['f3_name'];
  $f3_100 = preg_replace('~\D~', '', $_POST['f3_3kg']);
  $f3_150 = preg_replace('~\D~', '', $_POST['f3_6kg']);
  $f3_200 = preg_replace('~\D~', '', $_POST['f3_13kg']);
  $f3_250 = preg_replace('~\D~', '', $_POST['f3_15kg']);
  

  $f4_date = $_POST['f4_date'];
  $f4_name = $_POST['f4_name'];
  $f4_100 = preg_replace('~\D~', '', $_POST['f4_3kg']);
  $f4_150 = preg_replace('~\D~', '', $_POST['f4_6kg']);
  $f4_200 = preg_replace('~\D~', '', $_POST['f4_13kg']);
  $f4_250 = preg_replace('~\D~', '', $_POST['f4_15kg']);
  

  $f5_date = $_POST['f5_date'];
  $f5_name = $_POST['f5_name'];
  $f5_100 = preg_replace('~\D~', '', $_POST['f5_3kg']);
  $f5_150 = preg_replace('~\D~', '', $_POST['f5_6kg']);
  $f5_200 = preg_replace('~\D~', '', $_POST['f5_13kg']);
  $f5_250 = preg_replace('~\D~', '', $_POST['f5_15kg']);
  

  $f6_date = $_POST['f6_date'];
  $f6_name = $_POST['f6_name'];
  $f6_100 = preg_replace('~\D~', '', $_POST['f6_3kg']);
  $f6_150 = preg_replace('~\D~', '', $_POST['f6_6kg']);
  $f6_200 = preg_replace('~\D~', '', $_POST['f6_13kg']);
  $f6_250 = preg_replace('~\D~', '', $_POST['f6_15kg']);
  

  $f7_date = $_POST['f7_date'];
  $f7_name = $_POST['f7_name'];
  $f7_100 = preg_replace('~\D~', '', $_POST['f7_3kg']);
  $f7_150 = preg_replace('~\D~', '', $_POST['f7_6kg']);
  $f7_200 = preg_replace('~\D~', '', $_POST['f7_13kg']);
  $f7_250 = preg_replace('~\D~', '', $_POST['f7_15kg']);
  

  $f8_date = $_POST['f8_date'];
  $f8_name = $_POST['f8_name'];
  $f8_100 = preg_replace('~\D~', '', $_POST['f8_3kg']);
  $f8_150 = preg_replace('~\D~', '', $_POST['f8_6kg']);
  $f8_200 = preg_replace('~\D~', '', $_POST['f8_13kg']);
  $f8_250 = preg_replace('~\D~', '', $_POST['f8_15kg']);
  

  // get all products in an array
$myquery = "SELECT pname FROM aproducts";
  $result = $db ->query($myquery);
  $products = array();
  while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
    array_push($products, $row['pname']);
   }

if (isset($products[0])){$prod_0=$products[0];}else{$prod_0='';}
if (isset($products[1])){$prod_1=$products[1];}else{$prod_1='';} 
if (isset($products[2])){$prod_2=$products[2];}else{$prod_2='';} 
if (isset($products[3])){$prod_3=$products[3];}else{$prod_3='';} 
if (isset($products[4])){$prod_4=$products[4];}else{$prod_4='';} 
if (isset($products[5])){$prod_5=$products[5];}else{$prod_5='';}
if (isset($products[6])){$prod_6=$products[6];}else{$prod_6='';} 
if (isset($products[7])){$prod_7=$products[7];}else{$prod_7='';}

$prod_1_prices = "SELECT * FROM aproducts WHERE pname ='$prod_0'";
$result_prod_1_prices = $db ->query($prod_1_prices);
while ($row = $result_prod_1_prices->fetchArray(SQLITE3_ASSOC)) {
    $bp_prod_1_100=$row['bp_100'];
    $bp_prod_1_150=$row['bp_150'];
    $bp_prod_1_200=$row['bp_200'];
    $bp_prod_1_250=$row['bp_250'];
    
    $sp_prod_1_100=$row['sp_100'];
    $sp_prod_1_150=$row['sp_150'];
    $sp_prod_1_200=$row['sp_200'];
    $sp_prod_1_250=$row['sp_250'];
   
    //echo "this other; <br>$sp_prod_1_100<br> $sp_prod_1_150<br> $sp_prod_1_200<br> $sp_prod_1_250<br> $sp_prod_1_500";
   }
   if (!isset($sp_prod_1_100)) {$sp_prod_1_100 = '0';}
if (!isset($sp_prod_1_150)) {$sp_prod_1_150 = '0';}
if (!isset($sp_prod_1_200)) {$sp_prod_1_200 = '0';}
if (!isset($sp_prod_1_250)) {$sp_prod_1_250 = '0';}

if (!isset($bp_prod_1_100)) {$bp_prod_1_100 = '0';}
if (!isset($bp_prod_1_150)) {$bp_prod_1_150 = '0';}
if (!isset($bp_prod_1_200)) {$bp_prod_1_200 = '0';}
if (!isset($bp_prod_1_250)) {$bp_prod_1_250 = '0';}

$sp_prod_1_150= preg_replace('~\D~', '', $sp_prod_1_150);
$sp_prod_1_100= preg_replace('~\D~', '', $sp_prod_1_100);
$sp_prod_1_200= preg_replace('~\D~', '', $sp_prod_1_200);
$sp_prod_1_250= preg_replace('~\D~', '', $sp_prod_1_250);

$bp_prod_1_100= preg_replace('~\D~', '', $sp_prod_1_100);
$bp_prod_1_150= preg_replace('~\D~', '', $bp_prod_1_150);
$bp_prod_1_200= preg_replace('~\D~', '', $bp_prod_1_200);
$bp_prod_1_250= preg_replace('~\D~', '', $bp_prod_1_250);


$prod_2_prices = "SELECT * FROM aproducts WHERE pname ='$prod_1'";
$result_prod_2_prices = $db ->query($prod_2_prices);
while ($row = $result_prod_1_prices->fetchArray(SQLITE3_ASSOC)) {
    $bp_prod_2_100=$row['bp_100'];
    $bp_prod_2_150=$row['bp_150'];
    $bp_prod_2_200=$row['bp_200'];
    $bp_prod_2_250=$row['bp_250'];
   
    $sp_prod_2_100=$row['sp_100'];
    $sp_prod_2_150=$row['sp_150'];
    $sp_prod_2_200=$row['sp_200'];
    $sp_prod_2_250=$row['sp_250'];
    
   }
   if (!isset($sp_prod_2_100)) {$sp_prod_2_100 = '0';}
if (!isset($sp_prod_2_150)) {$sp_prod_2_150 = '0';}
if (!isset($sp_prod_2_200)) {$sp_prod_2_200 = '0';}
if (!isset($sp_prod_2_250)) {$sp_prod_2_250 = '0';}

if (!isset($bp_prod_2_100)) {$bp_prod_2_100 = '0';}
if (!isset($bp_prod_2_150)) {$bp_prod_2_150 = '0';}
if (!isset($bp_prod_2_200)) {$bp_prod_2_200 = '0';}
if (!isset($bp_prod_2_250)) {$bp_prod_2_250 = '0';}

$sp_prod_2_150= preg_replace('~\D~', '', $sp_prod_2_150);
$sp_prod_2_100= preg_replace('~\D~', '', $sp_prod_2_100);
$sp_prod_2_200= preg_replace('~\D~', '', $sp_prod_2_200);
$sp_prod_2_250= preg_replace('~\D~', '', $sp_prod_2_250);

$bp_prod_2_100= preg_replace('~\D~', '', $sp_prod_2_100);
$bp_prod_2_150= preg_replace('~\D~', '', $bp_prod_2_150);
$bp_prod_2_200= preg_replace('~\D~', '', $bp_prod_2_200);
$bp_prod_2_250= preg_replace('~\D~', '', $bp_prod_2_250);


$prod_3_prices = "SELECT * FROM aproducts WHERE pname ='$prod_2'";
$result_prod_3_prices = $db ->query($prod_3_prices);
while ($row = $result_prod_1_prices->fetchArray(SQLITE3_ASSOC)) {
    $bp_prod_3_100=$row['bp_100'];
    $bp_prod_3_150=$row['bp_150'];
    $bp_prod_3_200=$row['bp_200'];
    $bp_prod_3_250=$row['bp_250'];
    
    $sp_prod_3_100=$row['sp_100'];
    $sp_prod_3_150=$row['sp_150'];
    $sp_prod_3_200=$row['sp_200'];
    $sp_prod_3_250=$row['sp_250'];
    
   }
   if (!isset($sp_prod_3_100)) {$sp_prod_3_100 = '0';}
if (!isset($sp_prod_3_150)) {$sp_prod_3_150 = '0';}
if (!isset($sp_prod_3_200)) {$sp_prod_3_200 = '0';}
if (!isset($sp_prod_3_250)) {$sp_prod_3_250 = '0';}

if (!isset($bp_prod_3_100)) {$bp_prod_3_100 = '0';}
if (!isset($bp_prod_3_150)) {$bp_prod_3_150 = '0';}
if (!isset($bp_prod_3_200)) {$bp_prod_3_200 = '0';}
if (!isset($bp_prod_3_250)) {$bp_prod_3_250 = '0';}

$sp_prod_3_150= preg_replace('~\D~', '', $sp_prod_3_150);
$sp_prod_3_100= preg_replace('~\D~', '', $sp_prod_3_100);
$sp_prod_3_200= preg_replace('~\D~', '', $sp_prod_3_200);
$sp_prod_3_250= preg_replace('~\D~', '', $sp_prod_3_250);

$bp_prod_3_100= preg_replace('~\D~', '', $sp_prod_3_100);
$bp_prod_3_150= preg_replace('~\D~', '', $bp_prod_3_150);
$bp_prod_3_200= preg_replace('~\D~', '', $bp_prod_3_200);
$bp_prod_3_250= preg_replace('~\D~', '', $bp_prod_3_250);


 $prod_4_prices = "SELECT * FROM aproducts WHERE pname ='$prod_3'";
$result_prod_4_prices = $db ->query($prod_4_prices);
while ($row = $result_prod_1_prices->fetchArray(SQLITE3_ASSOC)) {
    $bp_prod_4_100=$row['bp_100'];
    $bp_prod_4_150=$row['bp_150'];
    $bp_prod_4_200=$row['bp_200'];
    $bp_prod_4_250=$row['bp_250'];
    
    $sp_prod_4_100=$row['sp_100'];
    $sp_prod_4_150=$row['sp_150'];
    $sp_prod_4_200=$row['sp_200'];
    $sp_prod_4_250=$row['sp_250'];
    
   }
   if (!isset($sp_prod_4_100)) {$sp_prod_4_100 = '0';}
if (!isset($sp_prod_4_150)) {$sp_prod_4_150 = '0';}
if (!isset($sp_prod_4_200)) {$sp_prod_4_200 = '0';}
if (!isset($sp_prod_4_250)) {$sp_prod_4_250 = '0';}

if (!isset($bp_prod_4_100)) {$bp_prod_4_100 = '0';}
if (!isset($bp_prod_4_150)) {$bp_prod_4_150 = '0';}
if (!isset($bp_prod_4_200)) {$bp_prod_4_200 = '0';}
if (!isset($bp_prod_4_250)) {$bp_prod_4_250 = '0';}

$sp_prod_4_150= preg_replace('~\D~', '', $sp_prod_4_150);
$sp_prod_4_100= preg_replace('~\D~', '', $sp_prod_4_100);
$sp_prod_4_200= preg_replace('~\D~', '', $sp_prod_4_200);
$sp_prod_4_250= preg_replace('~\D~', '', $sp_prod_4_250);

$bp_prod_4_100= preg_replace('~\D~', '', $sp_prod_4_100);
$bp_prod_4_150= preg_replace('~\D~', '', $bp_prod_4_150);
$bp_prod_4_200= preg_replace('~\D~', '', $bp_prod_4_200);
$bp_prod_4_250= preg_replace('~\D~', '', $bp_prod_4_250);


$prod_5_prices = "SELECT * FROM aproducts WHERE pname ='$prod_4'";
$result_prod_5_prices = $db ->query($prod_5_prices);
while ($row = $result_prod_5_prices->fetchArray(SQLITE3_ASSOC)) {
    $bp_prod_5_100=$row['bp_100'];
    $bp_prod_5_150=$row['bp_150'];
    $bp_prod_5_200=$row['bp_200'];
    $bp_prod_5_250=$row['bp_250'];
    
    $sp_prod_5_100=$row['sp_100'];
    $sp_prod_5_150=$row['sp_150'];
    $sp_prod_5_200=$row['sp_200'];
    $sp_prod_5_250=$row['sp_250'];
   
   }
if (!isset($sp_prod_5_100)) {$sp_prod_5_100 = '0';}
if (!isset($sp_prod_5_150)) {$sp_prod_5_150 = '0';}
if (!isset($sp_prod_5_200)) {$sp_prod_5_200 = '0';}
if (!isset($sp_prod_5_250)) {$sp_prod_5_250 = '0';}

if (!isset($bp_prod_5_100)) {$bp_prod_5_100 = '0';}
if (!isset($bp_prod_5_150)) {$bp_prod_5_150 = '0';}
if (!isset($bp_prod_5_200)) {$bp_prod_5_200 = '0';}
if (!isset($bp_prod_5_250)) {$bp_prod_5_250 = '0';}

$sp_prod_5_150= preg_replace('~\D~', '', $sp_prod_5_150);
$sp_prod_5_100= preg_replace('~\D~', '', $sp_prod_5_100);
$sp_prod_5_200= preg_replace('~\D~', '', $sp_prod_5_200);
$sp_prod_5_250= preg_replace('~\D~', '', $sp_prod_5_250);

$bp_prod_5_100= preg_replace('~\D~', '', $sp_prod_5_100);
$bp_prod_5_150= preg_replace('~\D~', '', $bp_prod_5_150);
$bp_prod_5_200= preg_replace('~\D~', '', $bp_prod_5_200);
$bp_prod_5_250= preg_replace('~\D~', '', $bp_prod_5_250);


$prod_6_prices = "SELECT * FROM aproducts WHERE pname ='$prod_5'";
$result_prod_6_prices = $db ->query($prod_6_prices);
while ($row = $result_prod_6_prices->fetchArray(SQLITE3_ASSOC)) {
    $bp_prod_6_100=$row['bp_100'];
    $bp_prod_6_150=$row['bp_150'];
    $bp_prod_6_200=$row['bp_200'];
    $bp_prod_6_250=$row['bp_250'];
    
    $sp_prod_6_100=$row['sp_100'];
    $sp_prod_6_150=$row['sp_150'];
    $sp_prod_6_200=$row['sp_200'];
    $sp_prod_6_250=$row['sp_250'];
    
   }
   if (!isset($sp_prod_6_100)) {$sp_prod_6_100 = '0';}
if (!isset($sp_prod_6_150)) {$sp_prod_6_150 = '0';}
if (!isset($sp_prod_6_200)) {$sp_prod_6_200 = '0';}
if (!isset($sp_prod_6_250)) {$sp_prod_6_250 = '0';}

if (!isset($bp_prod_6_100)) {$bp_prod_6_100 = '0';}
if (!isset($bp_prod_6_150)) {$bp_prod_6_150 = '0';}
if (!isset($bp_prod_6_200)) {$bp_prod_6_200 = '0';}
if (!isset($bp_prod_6_250)) {$bp_prod_6_250 = '0';}

$sp_prod_6_150= preg_replace('~\D~', '', $sp_prod_6_150);
$sp_prod_6_100= preg_replace('~\D~', '', $sp_prod_6_100);
$sp_prod_6_200= preg_replace('~\D~', '', $sp_prod_6_200);
$sp_prod_6_250= preg_replace('~\D~', '', $sp_prod_6_250);

$bp_prod_6_100= preg_replace('~\D~', '', $sp_prod_6_100);
$bp_prod_6_150= preg_replace('~\D~', '', $bp_prod_6_150);
$bp_prod_6_200= preg_replace('~\D~', '', $bp_prod_6_200);
$bp_prod_6_250= preg_replace('~\D~', '', $bp_prod_6_250);


$prod_7_prices = "SELECT * FROM aproducts WHERE pname ='$prod_6'";
$result_prod_7_prices = $db ->query($prod_7_prices);
while ($row = $result_prod_1_prices->fetchArray(SQLITE3_ASSOC)) {
    $bp_prod_7_100=$row['bp_100'];
    $bp_prod_7_150=$row['bp_150'];
    $bp_prod_7_200=$row['bp_200'];
    $bp_prod_7_250=$row['bp_250'];

    $sp_prod_7_100=$row['sp_100'];
    $sp_prod_7_150=$row['sp_150'];
    $sp_prod_7_200=$row['sp_200'];
    $sp_prod_7_250=$row['sp_250'];
    
   }
   if (!isset($sp_prod_7_100)) {$sp_prod_7_100 = '0';}
if (!isset($sp_prod_7_150)) {$sp_prod_7_150 = '0';}
if (!isset($sp_prod_7_200)) {$sp_prod_7_200 = '0';}
if (!isset($sp_prod_7_250)) {$sp_prod_7_250 = '0';}

if (!isset($bp_prod_7_100)) {$bp_prod_7_100 = '0';}
if (!isset($bp_prod_7_150)) {$bp_prod_7_150 = '0';}
if (!isset($bp_prod_7_200)) {$bp_prod_7_200 = '0';}
if (!isset($bp_prod_7_250)) {$bp_prod_7_250 = '0';}

$sp_prod_7_150= preg_replace('~\D~', '', $sp_prod_7_150);
$sp_prod_7_100= preg_replace('~\D~', '', $sp_prod_7_100);
$sp_prod_7_200= preg_replace('~\D~', '', $sp_prod_7_200);
$sp_prod_7_250= preg_replace('~\D~', '', $sp_prod_7_250);

$bp_prod_7_100= preg_replace('~\D~', '', $sp_prod_7_100);
$bp_prod_7_150= preg_replace('~\D~', '', $bp_prod_7_150);
$bp_prod_7_200= preg_replace('~\D~', '', $bp_prod_7_200);
$bp_prod_7_250= preg_replace('~\D~', '', $bp_prod_7_250);


$prod_8_prices = "SELECT * FROM aproducts WHERE pname ='$prod_7'";
$result_prod_8_prices = $db ->query($prod_8_prices);
while ($row = $result_prod_1_prices->fetchArray(SQLITE3_ASSOC)) {
    $bp_prod_8_100=$row['bp_100'];
    $bp_prod_8_150=$row['bp_150'];
    $bp_prod_8_200=$row['bp_200'];
    $bp_prod_8_250=$row['bp_250'];
    
    $sp_prod_8_100=$row['sp_100'];
    $sp_prod_8_150=$row['sp_150'];
    $sp_prod_8_200=$row['sp_200'];
    $sp_prod_8_250=$row['sp_250'];
    
   }
   if (!isset($sp_prod_8_100)) {$sp_prod_8_100 = '0';}
if (!isset($sp_prod_8_150)) {$sp_prod_8_150 = '0';}
if (!isset($sp_prod_8_200)) {$sp_prod_8_200 = '0';}
if (!isset($sp_prod_8_250)) {$sp_prod_8_250 = '0';}

if (!isset($bp_prod_8_100)) {$bp_prod_8_100 = '0';}
if (!isset($bp_prod_8_150)) {$bp_prod_8_150 = '0';}
if (!isset($bp_prod_8_200)) {$bp_prod_8_200 = '0';}
if (!isset($bp_prod_8_250)) {$bp_prod_8_250 = '0';}

$sp_prod_8_150= preg_replace('~\D~', '', $sp_prod_8_150);
$sp_prod_8_100= preg_replace('~\D~', '', $sp_prod_8_100);
$sp_prod_8_200= preg_replace('~\D~', '', $sp_prod_8_200);
$sp_prod_8_250= preg_replace('~\D~', '', $sp_prod_8_250);

$bp_prod_8_100= preg_replace('~\D~', '', $sp_prod_8_100);
$bp_prod_8_150= preg_replace('~\D~', '', $bp_prod_8_150);
$bp_prod_8_200= preg_replace('~\D~', '', $bp_prod_8_200);
$bp_prod_8_250= preg_replace('~\D~', '', $bp_prod_8_250);


  


// total day sales calculation
   $prod_1_tsales= ($sp_prod_1_100*$f1_100)+($sp_prod_1_150*$f1_150)+($sp_prod_1_200*$f1_200)+($sp_prod_1_250*$f1_250);

   $prod_2_tsales= ($sp_prod_2_100*$f2_100)+($sp_prod_2_150*$f2_150)+($sp_prod_2_200*$f2_200)+($sp_prod_2_250*$f2_250);

   $prod_3_tsales= ($sp_prod_3_100*$f3_100)+($sp_prod_3_150*$f3_150)+($sp_prod_3_200*$f3_200)+($sp_prod_3_250*$f3_250);

   $prod_4_tsales= ($sp_prod_4_100*$f4_100)+($sp_prod_4_150*$f4_150)+($sp_prod_4_200*$f4_200)+($sp_prod_4_250*$f4_250);

     $prod_5_tsales= ($sp_prod_5_100*$f5_100)+($sp_prod_5_150*$f5_150)+($sp_prod_5_200*$f5_200)+($sp_prod_5_250*$f5_250);

   $prod_6_tsales= ($sp_prod_6_100*$f6_100)+($sp_prod_6_150*$f6_150)+($sp_prod_6_200*$f6_200)+($sp_prod_6_250*$f6_250);

   $prod_7_tsales= ($sp_prod_7_100*$f7_100)+($sp_prod_7_150*$f7_150)+($sp_prod_7_200*$f7_200)+($sp_prod_7_250*$f7_250);

   $prod_8_tsales= ($sp_prod_8_100*$f8_100)+($sp_prod_8_150*$f8_150)+($sp_prod_8_200*$f8_200)+($sp_prod_8_250*$f8_250);


   //calculate profit
   $prod_1_profit= $prod_1_tsales - (($bp_prod_1_100*$f1_100)+($bp_prod_1_150*$f1_150)+($bp_prod_1_200*$f1_200)+($bp_prod_1_250*$f1_250));
   $prod_2_profit= $prod_2_tsales - (($bp_prod_2_100*$f2_100)+($bp_prod_2_150*$f2_150)+($bp_prod_2_200*$f2_200)+($bp_prod_2_250*$f2_250));
   $prod_3_profit= $prod_3_tsales - (($bp_prod_3_100*$f3_100)+($bp_prod_3_150*$f3_150)+($bp_prod_3_200*$f3_200)+($bp_prod_3_250*$f3_250));
   $prod_4_profit= $prod_4_tsales - (($bp_prod_4_100*$f4_100)+($bp_prod_4_150*$f4_150)+($bp_prod_4_200*$f4_200)+($bp_prod_4_250*$f4_250));
   $prod_5_profit= $prod_5_tsales - (($bp_prod_5_100*$f5_100)+($bp_prod_5_150*$f5_150)+($bp_prod_5_200*$f5_200)+($bp_prod_5_250*$f5_250));
   $prod_6_profit= $prod_6_tsales - (($bp_prod_6_100*$f6_100)+($bp_prod_6_150*$f6_150)+($bp_prod_6_200*$f6_200)+($bp_prod_6_250*$f6_250));
   $prod_7_profit= $prod_7_tsales - (($bp_prod_7_100*$f7_100)+($bp_prod_7_150*$f7_150)+($bp_prod_7_200*$f7_200)+($bp_prod_7_250*$f7_250));
   $prod_8_profit= $prod_8_tsales - (($bp_prod_8_100*$f8_100)+($bp_prod_8_150*$f8_150)+($bp_prod_8_200*$f8_200)+($bp_prod_8_250*$f8_250));
   $gen1=randStrGen(9);
   $gen2=randStrGen(9);
   $gen3=randStrGen(9);
   $gen4=randStrGen(9);
   $gen5=randStrGen(9);
   $gen6=randStrGen(9);
   $gen7=randStrGen(9);



   function FixDayProfits($mdate, $profit){
      $db = new MyDB();
      $count ="SELECT * FROM day_profit WHERE date='$mdate'";
          $mresult = $db ->query($count);
          while ($row = $mresult->fetchArray(SQLITE3_ASSOC)) {
           $mval= $row["profit"];
        }
        if (is_null($mval)) {
          $db->query("INSERT INTO day_profit(date, profit)VALUES('$mdate', '$profit')");
         }else{
          $mq ="SELECT * FROM day_profit WHERE date='$mdate'";
          $result = $db ->query($mq);
          while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
           $val= $row["profit"];
        }
        $new_comp_profit= $val + $profit;
        $p_update= "UPDATE day_profit
          SET 
              profit='$new_comp_profit'
          WHERE
            date='$mdate'";
            $db ->query($p_update);
        }
   }
   
    $sql1 ="INSERT INTO comprehensive_sales(date, product, ml_100, ml_150, ml_200, ml_250, t_sales, profit, receipt)VALUES('$f1_date', '$f1_name', '$f1_100', '$f1_150', '$f1_200', '$f1_250', '$prod_1_tsales', '$prod_1_profit', '$gen1')";
	$db->query($sql1);
  FixDayProfits($f1_date, $prod_1_profit);

	$sql2 ="INSERT INTO comprehensive_sales(date, product, ml_100, ml_150, ml_200, ml_250, t_sales, profit, receipt)VALUES('$f2_date', '$f2_name', '$f2_100', '$f2_150', '$f2_200', '$f2_250', '$prod_2_tsales', '$prod_2_profit', '$gen2')";
	$db->query($sql2);
  FixDayProfits($f2_date, $prod_2_profit);

	$sql3 ="INSERT INTO comprehensive_sales(date, product, ml_100, ml_150, ml_200, ml_250, t_sales, profit, receipt)VALUES('$f3_date', '$f3_name', '$f3_100', '$f3_150', '$f3_200', '$f3_250', '$prod_3_tsales', '$prod_3_profit', '$gen3')";
	$db->query($sql3);
  FixDayProfits($f3_date, $prod_3_profit);

	$sql4 ="INSERT INTO comprehensive_sales(date, product, ml_100, ml_150, ml_200, ml_250, t_sales, profit, receipt)VALUES('$f4_date', '$f4_name', '$f4_100', '$f4_150', '$f4_200', '$f4_250', '$prod_4_tsales', '$prod_4_profit', '$gen4')";
	$db->query($sql4);
  FixDayProfits($f4_date, $prod_4_profit);

	 $sql5 ="INSERT INTO comprehensive_sales(date, product, ml_100, ml_150, ml_200, ml_250, t_sales, profit, receipt)VALUES('$f5_date', '$f5_name', '$f5_100', '$f5_150', '$f5_200', '$f5_250', '$prod_5_tsales', '$prod_5_profit', '$gen5')";
	 $db->query($sql5);
   FixDayProfits($f5_date, $prod_5_profit);

	$sql6 ="INSERT INTO comprehensive_sales(date, product, ml_100, ml_150, ml_200, ml_250, t_sales, profit, receipt)VALUES('$f6_date', '$f6_name', '$f6_100', '$f6_150', '$f6_200', '$f6_250', '$prod_6_tsales', '$prod_6_profit', '$gen6')";
	$db->query($sql6);
  FixDayProfits($f6_date, $prod_6_profit);

	$sql7 ="INSERT INTO comprehensive_sales(date, product, ml_100, ml_150, ml_200, ml_250, t_sales, profit, receipt)VALUES('$f7_date', '$f7_name', '$f7_100', '$f7_150', '$f7_200', '$f7_250', '$prod_7_tsales', '$prod_7_profit', '$gen7')";
	$db->query($sql7);
  FixDayProfits($f7_date, $prod_7_profit);

	$sql8 ="INSERT INTO comprehensive_sales(date, product, ml_100, ml_150, ml_200, ml_250, t_sales, profit, receipt)VALUES('$f8_date', '$f8_name', '$f8_100', '$f8_150', '$f8_200', '$f8_250', '$prod_8_tsales', '$prod_8_profit', '$gen8')";
	$db->query($sql8);
  FixDayProfits($f8_date, $prod_8_profit);

	$deletenull="DELETE FROM comprehensive_sales WHERE product=''";
	$db->query($deletenull);
  $deletenull2="DELETE FROM comprehensive_sales WHERE t_sales='0'";
  $db->query($deletenull2);


// ********************************************************************8*8*************
  // ****************************************************************************
  // *******************************************************************************
  // update calibration table
  $cquery = "SELECT product FROM prod_calibrations";
  $cresult = $db ->query($cquery);
  $cproducts = array();
  while ($crow = $cresult->fetchArray(SQLITE3_ASSOC)) {
    array_push($cproducts, $crow['product']);
   }
   if (isset($cproducts[0])){$cprod_0=$cproducts[0];}else{$cprod_0='';}
if (isset($cproducts[1])){$cprod_1=$cproducts[1];}else{$cprod_1='';} 
if (isset($cproducts[2])){$cprod_2=$cproducts[2];}else{$cprod_2='';} 
if (isset($cproducts[3])){$cprod_3=$cproducts[3];}else{$cprod_3='';} 
if (isset($cproducts[4])){$cprod_4=$cproducts[4];}else{$cprod_4='';} 
if (isset($cproducts[5])){$cprod_5=$cproducts[5];}else{$cprod_5='';}
if (isset($cproducts[6])){$cprod_6=$cproducts[6];}else{$cprod_6='';} 
if (isset($cproducts[7])){$cprod_7=$cproducts[7];}else{$cprod_7='';}

$prod_1_present = "SELECT * FROM prod_calibrations WHERE product ='$cprod_0'";
$result_prod_1_present = $db ->query($prod_1_present);
while ($row = $result_prod_1_present->fetchArray(SQLITE3_ASSOC)) {
    $p_prod_1_100=$row['ml_100'];
    $p_prod_1_150=$row['ml_150'];
    $p_prod_1_200=$row['ml_200'];
    $p_prod_1_250=$row['ml_250'];
   
   }

   $prod_2_present = "SELECT * FROM prod_calibrations WHERE product ='$cprod_1'";
$result_prod_2_present = $db ->query($prod_2_present);
while ($row = $result_prod_2_present->fetchArray(SQLITE3_ASSOC)) {
    $p_prod_2_100=$row['ml_100'];
    $p_prod_2_150=$row['ml_150'];
    $p_prod_2_200=$row['ml_200'];
    $p_prod_2_250=$row['ml_250'];
    
    
   }

   $prod_3_present = "SELECT * FROM prod_calibrations WHERE product ='$cprod_2'";
$result_prod_3_present = $db ->query($prod_3_present);
while ($row = $result_prod_3_present->fetchArray(SQLITE3_ASSOC)) {
    $p_prod_3_100=$row['ml_100'];
    $p_prod_3_150=$row['ml_150'];
    $p_prod_3_200=$row['ml_200'];
    $p_prod_3_250=$row['ml_250'];
    
    
   }

   $prod_4_present = "SELECT * FROM prod_calibrations WHERE product ='$cprod_3'";
$result_prod_4_present = $db ->query($prod_4_present);
while ($row = $result_prod_4_present->fetchArray(SQLITE3_ASSOC)) {
    $p_prod_4_100=$row['ml_100'];
    $p_prod_4_150=$row['ml_150'];
    $p_prod_4_200=$row['ml_200'];
    $p_prod_4_250=$row['ml_250'];
 
    
   }

   $prod_5_present = "SELECT * FROM prod_calibrations WHERE product ='$cprod_4'";
$result_prod_5_present = $db ->query($prod_5_present);
while ($row = $result_prod_5_present->fetchArray(SQLITE3_ASSOC)) {
    $p_prod_5_100=$row['ml_100'];
    $p_prod_5_150=$row['ml_150'];
    $p_prod_5_200=$row['ml_200'];
    $p_prod_5_250=$row['ml_250'];
    
    
   }

   $prod_6_present = "SELECT * FROM prod_calibrations WHERE product ='$cprod_5'";
$result_prod_6_present = $db ->query($prod_6_present);
while ($row = $result_prod_6_present->fetchArray(SQLITE3_ASSOC)) {
    $p_prod_6_100=$row['ml_100'];
    $p_prod_6_150=$row['ml_150'];
    $p_prod_6_200=$row['ml_200'];
    $p_prod_6_250=$row['ml_250'];
    
    
   }

   $prod_7_present = "SELECT * FROM prod_calibrations WHERE product ='$cprod_6'";
$result_prod_7_present = $db ->query($prod_7_present);
while ($row = $result_prod_7_present->fetchArray(SQLITE3_ASSOC)) {
    $p_prod_7_100=$row['ml_100'];
    $p_prod_7_150=$row['ml_150'];
    $p_prod_7_200=$row['ml_200'];
    $p_prod_7_250=$row['ml_250'];
    
    
   }

   $prod_8_present = "SELECT * FROM prod_calibrations WHERE product ='$cprod_7'";
$result_prod_8_present = $db ->query($prod_8_present);
while ($row = $result_prod_8_present->fetchArray(SQLITE3_ASSOC)) {
    $p_prod_8_100=$row['ml_100'];
    $p_prod_8_150=$row['ml_150'];
    $p_prod_8_200=$row['ml_200'];
    $p_prod_8_250=$row['ml_250'];
    
    
   }
// calculate new available
   if (!isset($f1_name) or !isset($f1_date)){
    $f1_100 = 0;
    $f1_150 = 0;
    $f1_200 = 0;
    $f1_250 = 0;
    
   } else{
   $new_p_prod_1_100 = $p_prod_1_100 - $f1_100;
   $new_p_prod_1_150 = $p_prod_1_150 - $f1_150;
   $new_p_prod_1_200 = $p_prod_1_200 - $f1_200;
   $new_p_prod_1_250 = $p_prod_1_250 - $f1_250;
  

   //echo "<h1>1;$new_p_prod_1_100<br> 2:$new_p_prod_1_150<br>3; $new_p_prod_1_200<br>4; $new_p_prod_1_250<br>5; $new_p_prod_1_500<h1>";

 $prod_1_update= "UPDATE prod_calibrations
SET 
    ml_100='$new_p_prod_1_100',
    ml_150='$new_p_prod_1_150',
    ml_200='$new_p_prod_1_200',
    ml_250='$new_p_prod_1_250'
   

WHERE
    product='$cprod_0'";
$db->query($prod_1_update);
}
if (!isset($f2_name) or !isset($f2_date)){
    $f2_100 = 0;
    $f2_150 = 0;
    $f2_200 = 0;
    $f2_250 = 0;
    
   } else{
   $new_p_prod_2_100 = $p_prod_2_100 - $f2_100;
   $new_p_prod_2_150 = $p_prod_2_150 - $f2_150;
   $new_p_prod_2_200 = $p_prod_2_200 - $f2_200;
   $new_p_prod_2_250 = $p_prod_2_250 - $f2_250;
   

   $prod_2_update="UPDATE prod_calibrations
SET 
    ml_100='$new_p_prod_2_100',
    ml_150='$new_p_prod_2_150',
    ml_200='$new_p_prod_2_200',
    ml_250='$new_p_prod_2_250'
   

WHERE
    product='$cprod_1'";
$db->query($prod_2_update);}

if (isset($f3_name)) {
   $new_p_prod_3_100 = $p_prod_3_100 - $f3_100;
   $new_p_prod_3_150 = $p_prod_3_150 - $f3_150;
   $new_p_prod_3_200 = $p_prod_3_200 - $f3_200;
   $new_p_prod_3_250 = $p_prod_3_250 - $f3_250;
  
$prod_3_update="UPDATE prod_calibrations
SET 
    ml_100='$new_p_prod_3_100',
    ml_150='$new_p_prod_3_150',
    ml_200='$new_p_prod_3_200',
    ml_250='$new_p_prod_3_250'
    

WHERE
    product='$cprod_2'";


$db->query($prod_3_update);}

if (isset($f4_name)) {
   $new_p_prod_4_100 = $p_prod_4_100 - $f4_100;
   $new_p_prod_4_150 = $p_prod_4_150 - $f4_150;
   $new_p_prod_4_200 = $p_prod_4_200 - $f4_200;
   $new_p_prod_4_250 = $p_prod_4_250 - $f4_250;
   
$prod_4_update="UPDATE prod_calibrations
SET 
    ml_100='$new_p_prod_4_100',
    ml_150='$new_p_prod_4_150',
    ml_200='$new_p_prod_4_200',
    ml_250='$new_p_prod_4_250'
    

WHERE
    product='$cprod_3'";

$db->query($prod_4_update);}

if (isset($f5_name)) {
   $new_p_prod_5_100 = $p_prod_5_100 - $f5_100;
   $new_p_prod_5_150 = $p_prod_5_150 - $f5_150;
   $new_p_prod_5_200 = $p_prod_5_200 - $f5_200;
   $new_p_prod_5_250 = $p_prod_5_250 - $f5_250;
   
$prod_5_update="UPDATE prod_calibrations
SET 
    ml_100='$new_p_prod_5_100',
    ml_150='$new_p_prod_5_150',
    ml_200='$new_p_prod_5_200',
    ml_250='$new_p_prod_5_250'
    

WHERE
    product='$cprod_4'";
$db->query($prod_5_update);}

if (isset($f6_name)) {
   $new_p_prod_6_100 = $p_prod_6_100 - $f6_100;
   $new_p_prod_6_150 = $p_prod_6_150 - $f6_150;
   $new_p_prod_6_200 = $p_prod_6_200 - $f6_200;
   $new_p_prod_6_250 = $p_prod_6_250 - $f6_250;
   
$prod_6_update="UPDATE prod_calibrations
SET 
    ml_100='$new_p_prod_6_100',
    ml_150='$new_p_prod_6_150',
    ml_200='$new_p_prod_6_200',
    ml_250='$new_p_prod_6_250'
    

WHERE
    product='$cprod_5'";
$db->query($prod_6_update);}

if (isset($f7_name)) {
   $new_p_prod_7_100 = $p_prod_7_100 - $f7_100;
   $new_p_prod_7_150 = $p_prod_7_150 - $f7_150;
   $new_p_prod_7_200 = $p_prod_7_200 - $f7_200;
   $new_p_prod_7_250 = $p_prod_7_250 - $f7_250;
   
$prod_7_update="UPDATE prod_calibrations
SET 
    ml_100='$new_p_prod_7_100',
    ml_150='$new_p_prod_7_150',
    ml_200='$new_p_prod_7_200',
    ml_250='$new_p_prod_7_250'
   

WHERE
    product='$cprod_6'";
$db->query($prod_7_update);}

if (isset($f2_name)) {
   $new_p_prod_8_100 = $p_prod_8_100 - $f8_100;
   $new_p_prod_8_150 = $p_prod_8_150 - $f8_150;
   $new_p_prod_8_200 = $p_prod_8_200 - $f8_200;
   $new_p_prod_8_250 = $p_prod_8_250 - $f8_250;
   
$prod_8_update="UPDATE prod_calibrations
SET 
    ml_100='$new_p_prod_8_100',
    ml_150='$new_p_prod_8_150',
    ml_200='$new_p_prod_8_200',
    ml_250='$new_p_prod_8_250'

WHERE
    product='$cprod_7'";
$db->query($prod_8_update);}


echo "<script> location.href='index.php'; </script>";
         exit;

?>

</body>
</html>
