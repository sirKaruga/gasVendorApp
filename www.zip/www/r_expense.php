<?php
class MyDB extends SQLite3{
    function __construct()
    {
      $this->open('gasdb.db');
    }
  }

  $db = new MyDB();

  $date = $_POST['date'];
  $amount = preg_replace('~\D~', '', $_POST['amount']);
  $detail = $_POST['detail'];

$i="INSERT INTO gas_expense(date, detail, amount) VALUES('$date', '$detail', '$amount')";
$db ->query($i);
 
$fetch= "SELECT * FROM day_profit WHERE date ='$date'";

$result = $db ->query($fetch);
while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
    $prof=$row['profit'];
   }
if (!isset($prof)) {
	$i2="INSERT INTO day_profit(date, profit) VALUES('$date', -'$amount')";
	$db ->query($i2);
}else{
 $newp= $prof - $amount;
   $pro="UPDATE day_profit
SET 
    profit='$newp'
WHERE
    date ='$date'";
$db->query($pro);
}
header('location:index.php');
?>