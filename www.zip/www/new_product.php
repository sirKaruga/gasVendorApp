<?php
	class MyDB extends SQLite3{
		function __construct()
		{
			$this->open('gasdb.db');
		}
	}

	$db = new MyDB();

	$pname =$_POST['pname'];
	$bp_100 =preg_replace('~\D~', '', $_POST['bp_3']);
	$sp_100 =preg_replace('~\D~', '', $_POST['sp_3']);
	$bp_150 =preg_replace('~\D~', '', $_POST['bp_6']);
	$sp_150 =preg_replace('~\D~', '', $_POST['sp_6']);
	$bp_200 =preg_replace('~\D~', '', $_POST['bp_13']);
	$sp_200 =preg_replace('~\D~', '', $_POST['sp_13']);
	$bp_250 =preg_replace('~\D~', '', $_POST['bp_15']);
	$sp_250 =preg_replace('~\D~', '', $_POST['sp_15']);

	$r_bp_100 =preg_replace('~\D~', '', $_POST['r_bp_3']);
	$r_sp_100 =preg_replace('~\D~', '', $_POST['r_sp_3']);
	$r_bp_150 =preg_replace('~\D~', '', $_POST['r_bp_6']);
	$r_sp_150 =preg_replace('~\D~', '', $_POST['r_sp_6']);
	$r_bp_200 =preg_replace('~\D~', '', $_POST['r_bp_13']);
	$r_sp_200 =preg_replace('~\D~', '', $_POST['r_sp_13']);
	$r_bp_250 =preg_replace('~\D~', '', $_POST['r_bp_15']);
	$r_sp_250 =preg_replace('~\D~', '', $_POST['r_sp_15']);

	$result = $db->query("SELECT * FROM aproducts WHERE pname = '$pname'");
	$row=$result->fetchArray(SQLITE3_ASSOC);
    // check for empty result
    if ($row != false) {
      // do something here if record exists
    	echo "A product with that name already exists";
    	?><br><a href="index.php"><button>Back Home</button></a><?php
    }else{
    	
    	$sql ="INSERT INTO aproducts(pname, bp_100, sp_100, bp_150, sp_150, bp_200, sp_200, bp_250, sp_250, r_bp_3kg, r_sp_3kg, r_bp_6kg, r_sp_6kg, r_bp_13kg, r_sp_13kg, r_bp_15kg, r_sp_15kg)VALUES('$pname', '$bp_100', '$sp_100', '$bp_150', '$sp_150', '$bp_200', '$sp_200', '$bp_250', '$sp_250', '$r_bp_100', '$r_sp_100', '$r_bp_150', '$r_sp_150', '$r_bp_200', '$r_sp_200', '$r_bp_250', '$r_sp_250');";
		$db->query($sql);

		$calibrator = "INSERT INTO prod_calibrations(product, ml_100, ml_150, ml_200, ml_250)VALUES('$pname', '0', '0', '0', '0')";
		$db->query($calibrator);
		$calibrator2 = "INSERT INTO empty_containers(product, _3kg, _6kg, _13kg, _15kg)VALUES('$pname', '0', '0', '0', '0')";
		$db->query($calibrator2);

		header("location:index.php");
    }
?>